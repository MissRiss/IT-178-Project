package newest.ilstu.myloginpage;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
/**
 * Created by littlecurl 2018/6/24
 */

public class DBOpenHelper extends SQLiteOpenHelper {
    /**
     * Declare a database variable db that comes with the AndroidSDK
     */
    private SQLiteDatabase db;

/ * *
* write a constructor of this class with a parameter of context, which is the path of the package in which the * class is located
* specifies the context, database name, factory default null value, and version number by default starting at 1
* super (context, "db_test", null, 1);
* set the database to writable state, which is automatically set to read-only unless memory is full
* /
    public DBOpenHelper(Context context){
        super(context,"db_test",null,1);
        db = getReadableDatabase();
    }

/ * *
* override two methods that must be overridden because class DBOpenHelper extends SQLiteOpenHelper
* and these two methods are the abstract methods declared in the abstract class SQLiteOpenHelper
* so you must override the abstract method in the subclass DBOpenHelper
* come to think of it, why does the rule have to be rewritten?
* because, a database table, is to be created first, and then inevitably to be added and deleted operations
* so there are two methods: onCreate() and onUpgrade()
* @ param db
* /
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS user(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "password TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS user");
        onCreate(db);
    }
    /**
     * Write custom add, delete, change and check methods
     * add()
     * delete()
     * update()
     * getAllData()
     */
    public void add(String name,String password){
        db.execSQL("INSERT INTO user (name,password) VALUES(?,?)",new Object[]{name,password});
    }
    public void delete(String name,String password){
        db.execSQL("DELETE FROM user WHERE name = AND password ="+name+password);
    }
    public void updata(String password){
        db.execSQL("UPDATE user SET password = ?",new Object[]{password});
    }

/ * *
* a method to query the entire contents of the table user
* we need a container to store the contents of the query for use.
* so defines a list of the ArrayList classes
* with the container, it's time to query the data from the table,
* now that the cursor is defined, write a while loop that lets the cursor swim from the top of the table to the * * bottom of the table
* store the data in the list container during the swim
* @ return
* /
    public ArrayList<User> getAllData(){

        ArrayList<User> list = new ArrayList<User>();
        Cursor cursor = db.query("user",null,null,null,null,null,"name DESC");
        while(cursor.moveToNext()){
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String password = cursor.getString(cursor.getColumnIndex("password"));
            list.add(new User(name,password));
        }
        return list;
    }
}

