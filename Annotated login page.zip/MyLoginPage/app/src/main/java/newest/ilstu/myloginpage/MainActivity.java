package newest.ilstu.myloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
/**
 * Created by littlecurl 2018/6/24
 */

/**
 * after such implements view.onclicklistener,
 * you can write the onClick event outside of the onCreate() method
 * this way, the code in the onCreate() method doesn't seem redundant
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {
        // Initializes the control object
        Button mBtMainLogout = findViewById(R.id.bt_main_logout);
        // Bind click listener
        mBtMainLogout.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.bt_main_logout) {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }
}

