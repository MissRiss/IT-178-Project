package newest.ilstu.myloginpage;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
/**
 * Created by littlecurl 2018/6/24
 */

/**
 * after such implements view.onclicklistener,
 * you can write the onClick event outside of the onCreate() method
 *
 */
public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    /**
     * declare the DBOpenHelper object you wrote yourself
     * DBOpenHelper(extends SQLiteOpenHelper) is primarily used
     * create data tables
     * and then the data table of the addition, delete, change, check operations
     */
    private DBOpenHelper mDBOpenHelper;
    private TextView mTvLoginactivityRegister;
    private RelativeLayout mRlLoginactivityTop;
    private EditText mEtLoginactivityUsername;
    private EditText mEtLoginactivityPassword;
    private LinearLayout mLlLoginactivityTwo;
    private Button mBtLoginactivityLogin;

    /**
     * override the onCreate() method when creating the Activity
     * save the instance state
     * super onCreate (savedInstanceState);
     * sets the configuration file for the contents of the view
     * the setContentView (R.l ayout. Activity_login);
     * this line of code actually puts the contents of the View layer, the layout, into the Activity for display
     * initializes the control object initView() in the view
     * instantiate the DBOpenHelper to be used for data queries later when logging validation is performed
     * mDBOpenHelper = new DBOpenHelper(this);
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();

        mDBOpenHelper = new DBOpenHelper(this);
    }

    /**
     * onCreae() large layout has been put in place, the next thing is to put in the layout
     * declare, instantiate, and then assign behavior to objects that have behavior
     * this allows you to combine the view-layer View, layout, with the control-layer Java
     */
    private void initView() {
        // Initialize controls
        mBtLoginactivityLogin = findViewById(R.id.bt_loginactivity_login);
        mTvLoginactivityRegister = findViewById(R.id.tv_loginactivity_register);
        mRlLoginactivityTop = findViewById(R.id.rl_loginactivity_top);
        mEtLoginactivityUsername = findViewById(R.id.et_loginactivity_username);
        mEtLoginactivityPassword = findViewById(R.id.et_loginactivity_password);
        mLlLoginactivityTwo = findViewById(R.id.ll_loginactivity_two);

        // Set the click event listener
        mBtLoginactivityLogin.setOnClickListener(this);
        mTvLoginactivityRegister.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            // Jump to the registration screen
            case R.id.tv_loginactivity_register:
                startActivity(new Intent(this, RegisterActivity.class));
                finish();
                break;
            /**
             * login verification:
             *
             * get the data entered in the text edit box from the object of the EditText and remove the Spaces on              * the left and right sides
             * String name = mEtLoginactivityUsername. GetText (). The toString (). The trim ();
             * String password = mEtLoginactivityPassword. GetText (). The toString (). The trim ();
             * check whether the username and password are null for match verification.
             * If (! TextUtils. IsEmpty (name) &&! TextUtils. IsEmpty (password)
             * then go through the for loop to see if it matches the data in the database
             * if (name.equals(user.getname ())) && password.equals(user.getpassword ()))
             * match = true as soon as it matches; Break;
             * otherwise match until the end match = false;
             *
             * after successful login, page jump:
             *
             *  Intent intent = new Intent(this, MainActivity.class);
             *  startActivity(intent);
             *  finish();
             */
            case R.id.bt_loginactivity_login:
                String name = mEtLoginactivityUsername.getText().toString().trim();
                String password = mEtLoginactivityPassword.getText().toString().trim();
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(password)) {
                    ArrayList<User> data = mDBOpenHelper.getAllData();
                    boolean match = false;
                    for (int i = 0; i < data.size(); i++) {
                        User user = data.get(i);
                        if (name.equals(user.getName()) && password.equals(user.getPassword())) {
                            match = true;
                            break;
                        } else {
                            match = false;
                        }
                    }
                    if (match) {
                        Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, MainActivity.class);
                        startActivity(intent);
                        finish();//Destroy the Activity
                    } else {
                        Toast.makeText(this, "The user name or password is incorrect. Please enter it again", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Please enter your username or password", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}