package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText mEditText_username;
    private EditText mEditText_password;
    private Button mButton_login;
    private String str_username;
    private String str_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mEditText_username=findViewById(R.id.editText);
        mEditText_password=findViewById(R.id.editText2);
        mButton_login=findViewById(R.id.button3);
        mButton_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_username=mEditText_username.getText().toString();
                str_password=mEditText_password.getText().toString();
                if(str_username.length()<5){
                    Toast.makeText(Login.this,"User name must be longer than four digits",Toast.LENGTH_LONG).show();
                }else if(str_password.length()<7){
                    Toast.makeText(Login.this,"Password must be longer than six digits",Toast.LENGTH_LONG).show();
                }else if(str_username.equals("JiaweiYu")&&str_password.equals("JiaweiYu")){
                    Intent intent=new Intent(Login.this,Interest_Activity.class);
                    startActivity(intent );
                }else
                    Toast.makeText(Login.this,"The username and password do not match",Toast.LENGTH_LONG).show();

            }
        });
    }

}
