package com.example.quackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Random;

import in.galaxyofandroid.spinerdialog.OnSpinerItemClick;
import in.galaxyofandroid.spinerdialog.SpinnerDialog;

public class spinnerActivity extends AppCompatActivity {
    ArrayList<String> interests =new ArrayList<>();
    SpinnerDialog spinner;
    Button buttonSearch;

    @Override
    protected void onCreate(Bundle savedIntanceState){
        super.onCreate(savedIntanceState);
        setContentView(R.layout.spinner);

        Intent intent = getIntent();
        String interest= intent.getStringExtra("interest");

        interestItems();
        spinner = new SpinnerDialog(spinnerActivity.this, interests, "Select an interest");
        spinner.bindOnSpinerListener(new OnSpinerItemClick() {

            @Override
            public void onClick(String interest, int position) {
                Toast.makeText(spinnerActivity.this, "Selected: "+interest, Toast.LENGTH_SHORT).show();
                interestSelect(position);
            }
        });

        buttonSearch = (Button)findViewById(R.id.buttonSearch);
        buttonSearch.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                spinner.showSpinerDialog();
            }
        });

    }

    private void interestItems() {
        interests.add("Art");
        interests.add("Technology");
        interests.add("All Interests");
    }

    private void interestSelect(int position){
        Random random = new Random();

        ArrayList<String> artInterest = new ArrayList<>();
        ArrayList<String> techInterest = new ArrayList<>();
        ArrayList<String> allInterest = new ArrayList<>();

        allInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        allInterest.add("https://www.artsy.net/");
        allInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");
        allInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        allInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        allInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");

        artInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        artInterest.add("https://www.artsy.net/");
        artInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");

        techInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        techInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        techInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");


        Intent intent = new Intent(getApplicationContext(), MainActivity.class);


        if(position==0){
            intent.putStringArrayListExtra("artArray",techInterest);
            intent.putExtra("artLink", artInterest.get(random.nextInt(artInterest.size())));
            intent.putExtra("Chosen",true);
            intent.putExtra("Chosen1", false);
            intent.putExtra("Chosen2", false);
            startActivity(intent);}

        if(position==1){
            intent.putStringArrayListExtra("techArray",artInterest);
            intent.putExtra("techLink", techInterest.get(random.nextInt(techInterest.size())));
            intent.putExtra("Chosen1",true);
            intent.putExtra("Chosen", false);
            intent.putExtra("Chosen2", false);
            startActivity(intent);}

        if(position==2){
            intent.putStringArrayListExtra("allArray",allInterest);
            intent.putExtra("randLink", allInterest.get(random.nextInt(allInterest.size())));
            intent.putExtra("Chosen2",true);
            intent.putExtra("Chosen1", false);
            intent.putExtra("Chosen", false);
            startActivity(intent);}

    }
}