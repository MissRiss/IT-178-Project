package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        webView = findViewById(R.id.webview);
        Intent intent = getIntent();
        String rand = "";
        String art = "";
        String tech = "";


        rand = intent.getStringExtra("randLink");

        tech = intent.getStringExtra("techLink");

        art = intent.getStringExtra("artLink");


        //set JavaScript enable in web view
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(rand);
        webView.loadUrl(tech);
        webView.loadUrl(art);

    }
        public void openInterest (View view){
            Intent intentInt = new Intent(MainActivity.this, Interest_Activity.class);
            startActivity(intentInt);
        }

    public void search(View view){
        Intent intent= new Intent(this,spinnerActivity.class);
        intent.putExtra("interest",true);
        startActivity(intent);


    }

    public void shareURL(View view){
        String url = webView.getUrl();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("label",url);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(getApplicationContext(),"Link Copied", Toast.LENGTH_SHORT).show();

    }



    public void linkPressed(View view){

        ArrayList<String> techInterest = new ArrayList<>();
        ArrayList<String> allInterest = new ArrayList<>();
        ArrayList<String> artInterest = new ArrayList<>();

        Random random = new Random();

        Intent intent = getIntent();

        artInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        artInterest.add("https://www.artsy.net/");
        artInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");

        techInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        techInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        techInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");

        allInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        allInterest.add("https://www.artsy.net/");
        allInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");
        allInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        allInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        allInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");

        if(intent.getBooleanExtra("Chosen", true))
            webView.loadUrl(artInterest.get(random.nextInt(artInterest.size())));
        if (intent.getBooleanExtra("Chosen1", true))
            webView.loadUrl(techInterest.get(random.nextInt(techInterest.size())));
        if(intent.getBooleanExtra("Chosen2", true))
            webView.loadUrl(allInterest.get(random.nextInt(allInterest.size())));


        }


    }











