package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        webView = findViewById(R.id.webview);
        Intent intent = getIntent();
        String rand = "";
        String art = "";
        String tech = "";


        rand = intent.getStringExtra("randLink");

        Intent intent2 = getIntent();
        tech = intent2.getStringExtra("techLink");

        Intent intent3 = getIntent();
        art = intent3.getStringExtra("artLink");


        //set JavaScript enable in web view
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(rand);
        webView.loadUrl(tech);
        webView.loadUrl(art);

    }
        public void openInterest (View view){
            Intent intentInt = new Intent(MainActivity.this, Interest_Activity.class);
            startActivity(intentInt);
        }

    public void search(View view){
        Intent intent= new Intent(this,spinnerActivity.class);
        intent.putExtra("interest",true);
        startActivity(intent);


    }

    public void shareURL(View view){
        String url = webView.getUrl();
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("label",url);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(getApplicationContext(),"Link Copied", Toast.LENGTH_SHORT).show();

    }

    }









