package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Interest_Activity extends AppCompatActivity {

    private static Random random = new Random();
    public String url;

    ArrayList<String> artInterest = new ArrayList<>();
    ArrayList<String> techInterest = new ArrayList<>();
    ArrayList<String> allInterest = new ArrayList<>();
    ArrayList<String> chosen = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest_);


        ImageButton button1 = findViewById(R.id.imageButton6);
        ImageButton button2 = findViewById(R.id.imageButton8);
        ImageButton button3 = findViewById(R.id.imageButton7);
        Button button;

        artInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        artInterest.add("https://www.artsy.net/");
        artInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");

        techInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        techInterest.add("https://www.techrepublic.com/article/more-windows-10-run-commands-you-should-know-but-probably-forgot/?ftag=COS-05-10aaa0g&taid=5e9f56ccf87ad2000116245c&utm_campaign=trueAnthem:+Twitter+Card&utm_medium=trueAnthemCard&utm_source=twitterCard");
        techInterest.add("https://www.fastcompany.com/90491201/yale-students-3d-print-a-cheap-device-for-relieving-the-ventilator-shortage?partner=rss");

//        button1.setOnClickListener(onClick);
//        button2.setOnClickListener(this);
//        button3.setOnClickListener(this);


        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {

                                      @Override
                                      public void onClick(View v) {
                                          switch (v.getId()) {
                                              case R.id.imageButton6:
                                                  chosen = (ArrayList<String>) allInterest.clone();
                                                  break;
                                              case R.id.imageButton7:
                                                  chosen = (ArrayList<String>) artInterest.clone();
                                                  break;
                                              case R.id.imageButton8:
                                                  chosen = (ArrayList<String>) techInterest.clone();
                                                  break;
                                          }
                                          for (int i = 0; i < 100; i++) {
                                              url = chosen.get(random.nextInt(chosen.size()));
                                             }
                                      }
                                  });

    }
    public void loadWebpage(View v){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("selected_url", url);
        startActivity(intent);
    }}
//            for (int i = 0; i < 100; i++) {
//                chosen.get(random.nextInt(chosen.size()));
//            }
//        }
//        }}}
//    @Override
//    public void onClick(View v) {
//
//    }
//}



//            public void onItemSelected(View view){

//                ArrayList<String> chosen = null;
//                switch (view.getID()) {
//                    //Need to correctly set the choices - Right now it clones to an empty array list those values
//                    case 0:
//                        String choice = "All";
//                        chosen = (ArrayList<String>) allInterest.clone();
//                        break;
//
//                    case 1:
//                        choice = "Art";
//                        chosen = (ArrayList<String>) artInterest.clone();
//                        break;
//
//                    case 2:
//                        choice = "Tech";
//                        chosen = (ArrayList<String>) techInterest.clone();
//                        break;
//                }
//
//
//                for (int i = 0; i < 100; i++) {
//                    getRandItem(chosen);
//                }
//
//            }
//            @Override
//            public void onNothingSelected(AdapterView<?> parent){
//
//                }
//        });
//    }
//        private void getRandItem (List < String > list) {
//            int index = random.nextInt(list.size());
//        }
//    }


//                public void onNothingSelected(AdapterView<?> parent){
//
//                }
//
//                private void getRandItem(List<String> list) {
//                    int index = random.nextInt(list.size());
//                }
//
//    private void getRandItem(ArrayList<String> chosen) {
//        int index = random.nextInt(list.size());
//    }
//}

