package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Interest_Activity extends AppCompatActivity {

    private static Random random = new Random();

    ArrayList<String> artInterest = new ArrayList<>();
    ArrayList<String> techInterest = new ArrayList<>();
    ArrayList<String> allInterest = new ArrayList<>();
    ArrayList<String> chosen = new ArrayList<>();

    //define Spinner
    Spinner sp;

    //String Array for choices
    String interests[] = {"All", "Art", "Tech"};


    //Define ArrayAdapter of String Type
    ArrayAdapter <String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_interest_);

        artInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        artInterest.add("https://www.artsy.net/");
        artInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");

        techInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        techInterest.add("https://www.techrepublic.com/article/more-windows-10-run-commands-you-should-know-but-probably-forgot/?ftag=COS-05-10aaa0g&taid=5e9f56ccf87ad2000116245c&utm_campaign=trueAnthem:+Twitter+Card&utm_medium=trueAnthemCard&utm_source=twitterCard");
        techInterest.add("https://www.fastcompany.com/90491201/yale-students-3d-print-a-cheap-device-for-relieving-the-ventilator-shortage?partner=rss");

        sp = (Spinner)findViewById(R.id.spinner);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, interests);

        //set adapter to spinner
        sp.setAdapter(adapter);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                ArrayList<String> chosen = null;
                switch (position) {
                    //Need to correctly set the choices - Right now it clones to an empty array list those values
                    case 0:
                        String choice = "All";
                        chosen = (ArrayList<String>) allInterest.clone();
                        break;

                    case 1:
                        choice = "Art";
                        chosen = (ArrayList<String>) artInterest.clone();
                        break;

                    case 2:
                        choice = "Tech";
                        chosen = (ArrayList<String>) techInterest.clone();
                        break;
                }


                for (int i = 0; i < 100; i++) {
                    getRandItem(chosen);
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

                }
        });
    }
         private void getRandItem(List<String> list) {
             int index = random.nextInt(list.size());
         }
    }



//                public void onNothingSelected(AdapterView<?> parent){
//
//                }
//
//                private void getRandItem(List<String> list) {
//                    int index = random.nextInt(list.size());
//                }
//
//    private void getRandItem(ArrayList<String> chosen) {
//        int index = random.nextInt(list.size());
//    }
//}

