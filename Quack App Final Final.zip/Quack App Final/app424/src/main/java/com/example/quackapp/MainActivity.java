package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageButton button;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.webview);
        webView.setWebViewClient(new MyBrowser());

        //set JavaScript enable in web view
        webView.getSettings().setJavaScriptEnabled(true);

//        button = (ImageButton) findViewById(R.id.imageButton4);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openAct_2();
//            }
//        });

    }

    public void openAct_2() {
        Intent intent = new Intent(this, Interest_Activity.class);
        startActivity(intent);
    }

    public void open(View view){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(String.valueOf(chosenOption)));
        startActivity(browserIntent);
    }

    private class MyBrowser extends WebViewClient{
        @Override

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }


    Spinner spinner = (Spinner) findViewById(R.id.spinner);
    String chosenOption = spinner.getSelectedItem().toString();

    public void test (View view) {
        webView.loadUrl(chosenOption);

        //EditText editText = findViewById();
    }

}





