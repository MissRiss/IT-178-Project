package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        webView = findViewById(R.id.imageButton3);
//        webView.setWebViewClient(new MyBrowser());
//        //set JavaScript enable in web view
//
//        webView.getSettings().setJavaScriptEnabled(true);
//        webView.loadUrl("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
    }

    public void open(View view){
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/"));
        startActivity(browserIntent);
    }

//    private class MyBrowser extends WebViewClient{
//        @Override
//
//        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            view.loadUrl(url);
//            return true;
//        }
    }

    //test method for multiple click event

//    public void test (View view){
//
//        switch (view.getId()){
//            R.id.imageButton3:
//                webView.loadUrl("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
//                break;
//
//            EditText editText = findViewById()
//        }

//    }
//}
