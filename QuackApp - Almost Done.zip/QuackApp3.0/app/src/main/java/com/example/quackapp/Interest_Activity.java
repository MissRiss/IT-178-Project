package com.example.quackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;
import java.util.Random;

public class Interest_Activity extends AppCompatActivity {

    private static Random random = new Random();


    ArrayList<String> artInterest = new ArrayList<>();
    ArrayList<String> techInterest = new ArrayList<>();
    ArrayList<String> allInterest = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest_);


        ImageButton button1 = findViewById(R.id.imageButton6);
        ImageButton button2 = findViewById(R.id.imageButton8);
        ImageButton button3 = findViewById(R.id.imageButton7);
        Button button;

        allInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        allInterest.add("https://www.artsy.net/");
        allInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");
        allInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        allInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        allInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");

        artInterest.add("https://www.thejealouscurator.com/blog/art-for-your-ear-podcast/");
        artInterest.add("https://www.artsy.net/");
        artInterest.add("https://www.artnews.com/art-in-america/aia-reviews/allure-of-matter-material-art-from-china-smart-museum-wrightwood-659-wu-hung-1202683842/");

        techInterest.add("https://www.pcmag.com/news/report-apples-over-ear-airpods-feature-modular-magnetic-parts?taid=5e9f50f05a107f0001b4cd3f");
        techInterest.add("https://www.cnet.com/news/wild-vr-gadget-makes-virtual-objects-feel-solid-at-the-touch-of-your-hand/");
        techInterest.add("https://thenextweb.com/basics/2020/04/28/holy-sheet-how-to-create-qr-codes-with-google-sheets/");

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("randLink", allInterest.get(random.nextInt(allInterest.size())));
                startActivity(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), MainActivity.class);
                intent2.putExtra("artLink", artInterest.get(random.nextInt(artInterest.size())));
                startActivity(intent2);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(getApplicationContext(), MainActivity.class);
                intent3.putExtra("techLink", techInterest.get(random.nextInt(techInterest.size())));
                startActivity(intent3);
            }
        });
    }}
